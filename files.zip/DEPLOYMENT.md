# 🚀 Deployment Guide

## Quick Local Development Setup (5 minutes)

### Step 1: Prerequisites
```bash
# Verify installations
node --version  # Should be 18+
npm --version
psql --version  # PostgreSQL 14+
```

### Step 2: Clone and Setup
```bash
# Clone repository
git clone <your-repo-url>
cd ai-resume-trainer

# Install all dependencies
npm run install:all
```

### Step 3: Configure Environment
```bash
# Copy environment file
cp .env.example .env

# Edit .env and add:
# 1. Your OpenAI API Key (REQUIRED)
# 2. Database credentials
# 3. JWT secrets (generate random strings)

# Example:
# OPENAI_API_KEY=sk-your-key-here
# DATABASE_URL="postgresql://resumeuser:password@localhost:5432/resume_trainer"
# JWT_SECRET=$(openssl rand -base64 32)
```

### Step 4: Setup Database
```bash
# Create PostgreSQL database
createdb resume_trainer

# Generate Prisma client and push schema
npm run prisma:generate
npm run prisma:push
```

### Step 5: Start Development
```bash
# Start both frontend and backend
npm run dev

# Or start individually:
# Terminal 1: npm run dev:server
# Terminal 2: npm run dev:client
```

### Step 6: Access Application
- Frontend: http://localhost:5173
- Backend: http://localhost:5000
- API Health: http://localhost:5000/health

---

## 🐳 Docker Deployment (Easiest)

### Quick Start
```bash
# 1. Copy and configure environment
cp .env.example .env
# Edit .env with your OpenAI API key

# 2. Start everything
docker-compose up -d

# 3. Check status
docker-compose ps
docker-compose logs -f

# 4. Access at http://localhost:5173
```

### Docker Commands
```bash
# Stop services
docker-compose down

# Rebuild after code changes
docker-compose up -d --build

# View specific service logs
docker-compose logs backend
docker-compose logs frontend

# Access database
docker-compose exec postgres psql -U resumeuser -d resume_trainer

# Run Prisma commands
docker-compose exec backend npx prisma studio
```

---

## ☁️ Production Deployment

### Option 1: Railway (Recommended for Beginners)

#### Backend Deployment
1. Push code to GitHub
2. Go to [Railway.app](https://railway.app)
3. Click "New Project" → "Deploy from GitHub"
4. Select your repository
5. Add PostgreSQL service
6. Set environment variables:
   ```
   DATABASE_URL=${POSTGRES_URL}
   OPENAI_API_KEY=sk-your-key
   JWT_SECRET=your-secret-here
   JWT_REFRESH_SECRET=your-refresh-secret
   NODE_ENV=production
   ALLOWED_ORIGINS=https://your-frontend.vercel.app
   ```
7. Deploy! Railway will provide your backend URL

#### Frontend Deployment (Vercel)
1. Go to [Vercel.com](https://vercel.com)
2. Import your GitHub repository
3. Set root directory to `client`
4. Add environment variable:
   ```
   VITE_API_URL=https://your-railway-backend.railway.app/api
   ```
5. Deploy!

### Option 2: AWS (Advanced)

#### Backend (EC2 + RDS)
```bash
# 1. Launch EC2 instance (Ubuntu 22.04)
# 2. Install Node.js and dependencies
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs postgresql-client

# 3. Clone and setup
git clone <your-repo>
cd ai-resume-trainer/server
npm install
npx prisma generate

# 4. Setup PM2 for process management
sudo npm install -g pm2
pm2 start src/app.js --name "resume-trainer"
pm2 startup
pm2 save

# 5. Setup Nginx reverse proxy
sudo apt install nginx
# Configure nginx to proxy port 80 to 5000
```

#### Frontend (S3 + CloudFront)
```bash
# Build frontend
cd client
npm run build

# Deploy to S3
aws s3 sync dist/ s3://your-bucket-name

# Setup CloudFront distribution
# Point to S3 bucket
# Enable HTTPS with ACM certificate
```

### Option 3: DigitalOcean App Platform

1. Connect GitHub repository
2. Configure build settings:
   - Backend: Dockerfile
   - Frontend: Dockerfile
3. Add managed PostgreSQL database
4. Set environment variables
5. Deploy

---

## 🔐 Security Checklist for Production

### Before Deployment
- [ ] Change all default passwords
- [ ] Use strong JWT secrets (32+ characters)
- [ ] Set NODE_ENV=production
- [ ] Enable HTTPS/SSL certificates
- [ ] Update ALLOWED_ORIGINS to production domain
- [ ] Set up database backups
- [ ] Configure rate limiting
- [ ] Enable logging and monitoring
- [ ] Set up error tracking (Sentry)
- [ ] Configure CORS properly
- [ ] Validate all environment variables

### After Deployment
- [ ] Test all API endpoints
- [ ] Verify file upload works
- [ ] Test AI features (resume analysis, interviews)
- [ ] Check voice recording functionality
- [ ] Monitor error logs
- [ ] Set up uptime monitoring
- [ ] Configure backup strategy
- [ ] Test payment integration (if enabled)

---

## 📊 Monitoring and Maintenance

### Logging
```bash
# View application logs
tail -f server/logs/combined.log
tail -f server/logs/error.log

# With PM2
pm2 logs resume-trainer

# With Docker
docker-compose logs -f backend
```

### Health Checks
```bash
# Backend health
curl https://your-api.com/health

# Database connection
curl https://your-api.com/api/auth/me -H "Authorization: Bearer token"
```

### Database Backups
```bash
# Manual backup
pg_dump -U resumeuser resume_trainer > backup.sql

# Restore backup
psql -U resumeuser resume_trainer < backup.sql

# Automated daily backups (cron)
0 2 * * * pg_dump -U resumeuser resume_trainer > /backups/backup-$(date +\%Y\%m\%d).sql
```

---

## 🐛 Troubleshooting

### Common Issues

**Issue: "Cannot connect to database"**
```bash
# Check PostgreSQL is running
sudo systemctl status postgresql

# Verify DATABASE_URL is correct
echo $DATABASE_URL

# Test connection
psql $DATABASE_URL
```

**Issue: "OpenAI API errors"**
```bash
# Verify API key is set
echo $OPENAI_API_KEY

# Check API key validity
curl https://api.openai.com/v1/models \
  -H "Authorization: Bearer $OPENAI_API_KEY"

# Check billing and quota
# Visit: https://platform.openai.com/account/billing
```

**Issue: "JWT token expired"**
- Tokens expire after 15 minutes (access) or 7 days (refresh)
- Frontend should automatically refresh
- Check refresh token logic in api.js

**Issue: "File upload fails"**
```bash
# Check upload directory exists and has permissions
mkdir -p server/uploads
chmod 755 server/uploads

# Verify MAX_FILE_SIZE setting
echo $MAX_FILE_SIZE
```

**Issue: "CORS errors"**
- Verify ALLOWED_ORIGINS includes your frontend URL
- Check frontend VITE_API_URL points to correct backend
- Ensure credentials: true in CORS config

---

## 🔄 Update and Migration

### Updating Application
```bash
# Pull latest changes
git pull origin main

# Update dependencies
npm run install:all

# Update database schema
npm run prisma:push

# Restart services
pm2 restart resume-trainer

# Or with Docker
docker-compose down
docker-compose up -d --build
```

### Database Migration
```bash
# Create migration
cd server
npx prisma migrate dev --name migration_name

# Apply to production
npx prisma migrate deploy
```

---

## 💡 Performance Optimization

### Backend
- Enable Redis caching for frequently accessed data
- Use connection pooling for database
- Implement request queuing for AI operations
- Add CDN for static assets

### Frontend
- Enable gzip compression (nginx)
- Implement lazy loading for routes
- Optimize images and assets
- Use service workers for offline support

### Database
- Add indexes for frequently queried fields
- Implement query optimization
- Set up read replicas for analytics
- Regular VACUUM and ANALYZE

---

## 📈 Scaling Strategy

### Phase 1: Single Server (0-1,000 users)
- Single server deployment
- Managed database (RDS/Supabase)
- Basic monitoring

### Phase 2: Horizontal Scaling (1,000-10,000 users)
- Multiple backend instances behind load balancer
- Implement Redis for caching
- Separate AI processing to queue workers
- CDN for static assets

### Phase 3: Microservices (10,000+ users)
- Separate services: Auth, Resume, Interview, Analytics
- Message queue (RabbitMQ/AWS SQS)
- Dedicated AI processing cluster
- Advanced monitoring and alerting

---

## 🆘 Getting Help

- 📚 Documentation: See README.md
- 🐛 Issues: GitHub Issues
- 💬 Community: Discord/Slack
- 📧 Email: support@example.com

---

**Happy Deploying! 🚀**
