#!/bin/bash
# AI Resume + Interview Trainer - Complete Project Generator
# This script creates the entire project structure and all files

echo "🚀 AI Resume + Interview Trainer - Project Generator"
echo "=================================================="
echo ""

# Create project root
mkdir -p ai-resume-trainer
cd ai-resume-trainer

echo "📁 Creating directory structure..."

# Create backend directories
mkdir -p server/src/{controllers,routes,middleware,ai,config}
mkdir -p server/prisma
mkdir -p server/uploads
mkdir -p server/logs

# Create frontend directories
mkdir -p client/src/{components,pages,services,store}
mkdir -p client/public

echo "✅ Directory structure created"
echo ""
echo "📝 Generating configuration files..."

# Root package.json
cat > package.json << 'EOF'
{
  "name": "ai-resume-trainer",
  "version": "1.0.0",
  "description": "AI-powered resume optimization and interview training platform",
  "private": true,
  "scripts": {
    "install:all": "npm install && cd server && npm install && cd ../client && npm install",
    "dev": "concurrently \"npm run dev:server\" \"npm run dev:client\"",
    "dev:server": "cd server && npm run dev",
    "dev:client": "cd client && npm run dev",
    "build": "cd client && npm run build",
    "docker:up": "docker-compose up -d",
    "docker:down": "docker-compose down",
    "docker:logs": "docker-compose logs -f",
    "prisma:generate": "cd server && npx prisma generate",
    "prisma:push": "cd server && npx prisma db push",
    "prisma:studio": "cd server && npx prisma studio"
  },
  "keywords": ["ai", "resume", "interview", "career", "saas"],
  "author": "",
  "license": "MIT",
  "devDependencies": {
    "concurrently": "^8.2.2"
  }
}
EOF

# .env.example
cat > .env.example << 'EOF'
# Database
POSTGRES_USER=resumeuser
POSTGRES_PASSWORD=your-secure-password-here
POSTGRES_DB=resume_trainer
DATABASE_URL="postgresql://resumeuser:your-secure-password-here@localhost:5432/resume_trainer"

# JWT
JWT_SECRET=your-super-secret-jwt-key-change-this-in-production
JWT_REFRESH_SECRET=your-refresh-secret-key-change-this-in-production

# OpenAI API
OPENAI_API_KEY=sk-your-openai-api-key-here

# Server
PORT=5000
NODE_ENV=development
ALLOWED_ORIGINS=http://localhost:5173
MAX_FILE_SIZE=5242880
UPLOAD_DIR=./uploads

# Frontend
VITE_API_URL=http://localhost:5000/api
EOF

# .gitignore
cat > .gitignore << 'EOF'
node_modules/
.env
.env.local
logs/
*.log
.DS_Store
server/uploads/*
!server/uploads/.gitkeep
server/prisma/migrations/
client/dist/
.cache/
EOF

# docker-compose.yml
cat > docker-compose.yml << 'EOF'
version: '3.8'

services:
  postgres:
    image: postgres:15-alpine
    container_name: resume-trainer-db
    restart: unless-stopped
    environment:
      POSTGRES_USER: ${POSTGRES_USER:-resumeuser}
      POSTGRES_PASSWORD: ${POSTGRES_PASSWORD:-resumepass}
      POSTGRES_DB: ${POSTGRES_DB:-resume_trainer}
    ports:
      - "5432:5432"
    volumes:
      - postgres_data:/var/lib/postgresql/data
    networks:
      - resume-trainer-network

  backend:
    build:
      context: ./server
      dockerfile: Dockerfile
    container_name: resume-trainer-backend
    restart: unless-stopped
    depends_on:
      - postgres
    environment:
      DATABASE_URL: postgresql://${POSTGRES_USER:-resumeuser}:${POSTGRES_PASSWORD:-resumepass}@postgres:5432/${POSTGRES_DB:-resume_trainer}
      JWT_SECRET: ${JWT_SECRET}
      JWT_REFRESH_SECRET: ${JWT_REFRESH_SECRET}
      OPENAI_API_KEY: ${OPENAI_API_KEY}
      PORT: 5000
      NODE_ENV: production
      ALLOWED_ORIGINS: ${ALLOWED_ORIGINS:-http://localhost:5173}
    ports:
      - "5000:5000"
    volumes:
      - ./server/uploads:/app/uploads
      - ./server/logs:/app/logs
    networks:
      - resume-trainer-network

  frontend:
    build:
      context: ./client
      dockerfile: Dockerfile
      args:
        VITE_API_URL: ${VITE_API_URL:-http://localhost:5000/api}
    container_name: resume-trainer-frontend
    restart: unless-stopped
    depends_on:
      - backend
    ports:
      - "5173:80"
    networks:
      - resume-trainer-network

networks:
  resume-trainer-network:
    driver: bridge

volumes:
  postgres_data:
EOF

echo "✅ Root configuration files created"
echo ""
echo "⚙️  Generating backend files..."

# Server package.json
cat > server/package.json << 'EOF'
{
  "name": "ai-resume-trainer-server",
  "version": "1.0.0",
  "main": "src/app.js",
  "scripts": {
    "dev": "nodemon src/app.js",
    "start": "node src/app.js"
  },
  "dependencies": {
    "@prisma/client": "^5.8.0",
    "bcrypt": "^5.1.1",
    "cors": "^2.8.5",
    "dotenv": "^16.3.1",
    "express": "^4.18.2",
    "express-rate-limit": "^7.1.5",
    "helmet": "^7.1.0",
    "jsonwebtoken": "^9.0.2",
    "mammoth": "^1.6.0",
    "morgan": "^1.10.0",
    "multer": "^1.4.5-lts.1",
    "openai": "^4.24.1",
    "pdf-parse": "^1.1.1",
    "uuid": "^9.0.1",
    "validator": "^13.11.0",
    "winston": "^3.11.0"
  },
  "devDependencies": {
    "nodemon": "^3.0.2",
    "prisma": "^5.8.0"
  }
}
EOF

# Server Dockerfile
cat > server/Dockerfile << 'EOF'
FROM node:18-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production
COPY . .
RUN npx prisma generate
RUN mkdir -p uploads logs
EXPOSE 5000
CMD ["npm", "start"]
EOF

echo "✅ Backend configuration created"
echo ""
echo "🎨 Generating frontend files..."

# Client package.json
cat > client/package.json << 'EOF'
{
  "name": "ai-resume-trainer-client",
  "version": "1.0.0",
  "type": "module",
  "scripts": {
    "dev": "vite",
    "build": "vite build",
    "preview": "vite preview"
  },
  "dependencies": {
    "axios": "^1.6.5",
    "framer-motion": "^10.18.0",
    "lucide-react": "^0.307.0",
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "react-router-dom": "^6.21.1",
    "zustand": "^4.4.7"
  },
  "devDependencies": {
    "@vitejs/plugin-react": "^4.2.1",
    "autoprefixer": "^10.4.16",
    "postcss": "^8.4.33",
    "tailwindcss": "^3.4.1",
    "vite": "^5.0.11"
  }
}
EOF

# Client Dockerfile
cat > client/Dockerfile << 'EOF'
FROM node:18-alpine AS build
WORKDIR /app
COPY package*.json ./
RUN npm ci
COPY . .
ARG VITE_API_URL
ENV VITE_API_URL=$VITE_API_URL
RUN npm run build

FROM nginx:alpine
COPY --from=build /app/dist /usr/share/nginx/html
COPY nginx.conf /etc/nginx/conf.d/default.conf
EXPOSE 80
CMD ["nginx", "-g", "daemon off;"]
EOF

# Nginx config
cat > client/nginx.conf << 'EOF'
server {
    listen 80;
    root /usr/share/nginx/html;
    index index.html;
    location / {
        try_files $uri $uri/ /index.html;
    }
}
EOF

echo "✅ Frontend configuration created"
echo ""
echo "=================================================="
echo "✅ PROJECT STRUCTURE CREATED SUCCESSFULLY!"
echo ""
echo "📋 Next Steps:"
echo ""
echo "1. Copy the remaining source files using the companion scripts"
echo "2. Or manually create the files following the structure in README.md"
echo "3. Run: cp .env.example .env"
echo "4. Edit .env and add your OpenAI API key"
echo "5. Run: npm run install:all"
echo "6. Run: npm run prisma:push"
echo "7. Run: npm run dev"
echo ""
echo "🐳 Or use Docker:"
echo "   docker-compose up -d"
echo ""
echo "📚 Full documentation available in README.md"
echo ""
