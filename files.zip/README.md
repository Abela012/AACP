# 🚀 AI Resume + Interview Trainer

> **Transform your career with AI-powered resume optimization and interview practice**

A production-ready SaaS platform that helps job seekers improve their resumes, practice interviews with AI recruiters, and track their progress through detailed analytics.

![Stack](https://img.shields.io/badge/Stack-React%20%7C%20Node.js%20%7C%20PostgreSQL%20%7C%20OpenAI-blue)
![License](https://img.shields.io/badge/License-MIT-green)

---

## 📋 Table of Contents

- [Features](#-features)
- [Tech Stack](#-tech-stack)
- [Architecture](#-architecture)
- [Quick Start](#-quick-start)
- [Deployment](#-deployment)
- [API Documentation](#-api-documentation)
- [Contributing](#-contributing)

---

## ✨ Features

### Resume Optimization
- 📄 **Multi-format Support** - Upload PDF, DOCX, or TXT resumes
- 🎯 **ATS Scoring** - Get instant compatibility scores (0-100)
- 🤖 **AI Analysis** - Detailed feedback on strengths, weaknesses, and improvements
- 🔑 **Keyword Optimization** - Identify missing industry-relevant keywords
- 📊 **Progress Tracking** - Monitor ATS score improvements over time

### Mock Interviews
- 💬 **AI Recruiters** - Practice with adaptive AI interviewers
- 🎭 **Personality Types** - Friendly, Strict, Startup Founder, Corporate HR, Technical Lead
- 📝 **Interview Types** - HR, Technical, Behavioral, Case Study
- 🎤 **Voice Analysis** - Record audio responses for communication feedback
- 📈 **Scoring System** - Technical, communication, confidence, and clarity metrics

### Analytics Dashboard
- 📊 **Performance Metrics** - Track resume scores and interview performance
- 📈 **Trend Analysis** - Visualize improvement over time
- 🎯 **Weak Skills** - Identify areas needing improvement
- 🏆 **Achievements** - Celebrate milestones and progress

---

## 🛠 Tech Stack

### Frontend
- **React 18** - Modern UI library
- **Vite** - Lightning-fast build tool
- **TailwindCSS** - Utility-first styling
- **Framer Motion** - Smooth animations
- **Zustand** - Lightweight state management
- **Axios** - HTTP client with interceptors

### Backend
- **Node.js + Express** - REST API server
- **PostgreSQL** - Relational database
- **Prisma** - Type-safe ORM
- **JWT** - Secure authentication
- **OpenAI GPT-4** - Resume analysis & interviews
- **Whisper API** - Voice transcription

### DevOps
- **Docker** - Containerization
- **Docker Compose** - Multi-container orchestration
- **Nginx** - Production web server
- **Winston** - Logging

---

## 🏗 Architecture

```
┌─────────────────────────────────────────────────────────┐
│                     CLIENT (React)                       │
│  • Pages: Dashboard, Resumes, Interviews, Analytics     │
│  • State: Zustand + Local Storage                       │
│  • Styling: TailwindCSS + Custom Brutalist Theme        │
└─────────────────┬───────────────────────────────────────┘
                  │ HTTPS / REST API
                  │
┌─────────────────▼───────────────────────────────────────┐
│                 SERVER (Node.js + Express)               │
│  ┌──────────────────────────────────────────────────┐  │
│  │  Routes: /auth, /resumes, /interviews, /analytics│  │
│  └──────────────────────────────────────────────────┘  │
│  ┌──────────────────────────────────────────────────┐  │
│  │  Controllers: Business Logic Layer                │  │
│  └──────────────────────────────────────────────────┘  │
│  ┌──────────────────────────────────────────────────┐  │
│  │  AI Service: OpenAI Integration                   │  │
│  │  • Resume Analysis  • Interview Generation        │  │
│  │  • Answer Evaluation • Voice Transcription        │  │
│  └──────────────────────────────────────────────────┘  │
│  ┌──────────────────────────────────────────────────┐  │
│  │  Prisma ORM: Database Access Layer                │  │
│  └──────────────────────────────────────────────────┘  │
└─────────────────┬───────────────────────────────────────┘
                  │
┌─────────────────▼───────────────────────────────────────┐
│                 DATABASE (PostgreSQL)                    │
│  Tables: users, resumes, resume_feedback, interviews,   │
│          interview_questions, interview_answers,         │
│          subscriptions, analytics                        │
└─────────────────────────────────────────────────────────┘
```

---

## 🚀 Quick Start

### Prerequisites

- Node.js 18+ 
- PostgreSQL 14+
- OpenAI API Key ([Get one here](https://platform.openai.com/api-keys))

### Installation

1. **Clone the repository**
```bash
git clone <repository-url>
cd ai-resume-trainer
```

2. **Set up environment variables**
```bash
# Copy example env files
cp .env.example .env

# Edit .env and add your credentials
# IMPORTANT: Add your OpenAI API key!
```

3. **Install dependencies**
```bash
# Backend
cd server
npm install

# Frontend
cd ../client
npm install
```

4. **Set up the database**
```bash
cd server
npx prisma generate
npx prisma db push
```

5. **Start the application**

**Terminal 1 - Backend:**
```bash
cd server
npm run dev
```

**Terminal 2 - Frontend:**
```bash
cd client
npm run dev
```

6. **Access the application**
- Frontend: http://localhost:5173
- Backend API: http://localhost:5000/api
- Health Check: http://localhost:5000/health

---

## 🐳 Docker Deployment

### Quick Start with Docker

```bash
# Create .env file with your credentials
cp .env.example .env

# Start all services
docker-compose up -d

# View logs
docker-compose logs -f

# Stop services
docker-compose down
```

Services will be available at:
- Frontend: http://localhost:5173
- Backend: http://localhost:5000
- PostgreSQL: localhost:5432

### Production Deployment

#### Deploy Backend (Railway/Render)

1. Push code to GitHub
2. Connect Railway/Render to your repository
3. Set environment variables:
   - `DATABASE_URL`
   - `JWT_SECRET`
   - `JWT_REFRESH_SECRET`
   - `OPENAI_API_KEY`
   - `NODE_ENV=production`
   - `ALLOWED_ORIGINS=https://your-frontend-domain.com`
4. Deploy

#### Deploy Frontend (Vercel/Netlify)

1. Connect Vercel to your GitHub repository
2. Set build settings:
   - Build command: `npm run build`
   - Output directory: `dist`
   - Root directory: `client`
3. Set environment variable:
   - `VITE_API_URL=https://your-backend-api.com/api`
4. Deploy

#### Database (Supabase/Neon)

1. Create PostgreSQL database
2. Get connection string
3. Update `DATABASE_URL` in backend environment variables
4. Run migrations: `npx prisma db push`

---

## 📚 API Documentation

### Authentication

#### Register
```http
POST /api/auth/register
Content-Type: application/json

{
  "name": "John Doe",
  "email": "john@example.com",
  "password": "securepassword123"
}
```

#### Login
```http
POST /api/auth/login
Content-Type: application/json

{
  "email": "john@example.com",
  "password": "securepassword123"
}
```

#### Get Current User
```http
GET /api/auth/me
Authorization: Bearer <token>
```

### Resumes

#### Upload Resume
```http
POST /api/resumes/upload
Authorization: Bearer <token>
Content-Type: multipart/form-data

resume: <file>
```

#### Analyze Resume with AI
```http
POST /api/resumes/:id/analyze
Authorization: Bearer <token>
```

#### Get User Resumes
```http
GET /api/resumes
Authorization: Bearer <token>
```

### Interviews

#### Create Interview
```http
POST /api/interviews/create
Authorization: Bearer <token>
Content-Type: application/json

{
  "interviewType": "TECHNICAL",
  "industry": "Software Engineering",
  "difficulty": "MEDIUM",
  "recruiterPersonality": "FRIENDLY",
  "jobTitle": "Senior Software Engineer"
}
```

#### Submit Answer
```http
POST /api/interviews/:id/answer
Authorization: Bearer <token>
Content-Type: application/json

{
  "questionId": "question-uuid",
  "answerText": "Your answer here..."
}
```

#### Submit Voice Answer
```http
POST /api/interviews/:id/voice
Authorization: Bearer <token>
Content-Type: multipart/form-data

questionId: <uuid>
audio: <audio-file>
```

### Analytics

#### Get Dashboard
```http
GET /api/analytics/dashboard
Authorization: Bearer <token>
```

#### Get Detailed Analytics
```http
GET /api/analytics/detailed?timeRange=30d
Authorization: Bearer <token>
```

---

## 🎨 Design System

### Colors
- **Primary**: Blue tones (#627d98 - #102a43)
- **Accent**: Amber/Gold (#fbbf24 - #78350f)
- **Dark Mode**: Custom dark theme with refined brutalist aesthetic

### Typography
- **Display Font**: Unbounded (bold, geometric)
- **Body Font**: Inter (clean, readable)
- **Mono Font**: JetBrains Mono (technical content)

### Components
- **Brutal Cards**: Sharp borders, bold shadows
- **Angular Accents**: Geometric clip-paths
- **Score Badges**: Color-coded performance indicators
- **Grid Pattern**: Subtle background texture

---

## 📝 Environment Variables

See `.env.example` for all available configuration options.

**Critical Variables:**
- `OPENAI_API_KEY` - Required for AI features
- `DATABASE_URL` - PostgreSQL connection string
- `JWT_SECRET` - Secure token generation
- `JWT_REFRESH_SECRET` - Refresh token security

---

## 🧪 Testing

```bash
# Backend tests
cd server
npm test

# Frontend tests
cd client
npm test

# E2E tests
npm run test:e2e
```

---

## 📦 Project Structure

```
ai-resume-trainer/
├── client/                 # React frontend
│   ├── src/
│   │   ├── components/    # Reusable UI components
│   │   ├── pages/         # Route pages
│   │   ├── services/      # API services
│   │   ├── store/         # Zustand state
│   │   └── index.css      # Global styles
│   └── Dockerfile
│
├── server/                 # Node.js backend
│   ├── src/
│   │   ├── controllers/   # Business logic
│   │   ├── routes/        # API routes
│   │   ├── middleware/    # Express middleware
│   │   ├── ai/            # OpenAI integration
│   │   └── config/        # Configuration
│   ├── prisma/
│   │   └── schema.prisma  # Database schema
│   └── Dockerfile
│
├── docker-compose.yml      # Multi-container setup
└── README.md
```

---

## 🔒 Security Features

- ✅ JWT authentication with refresh tokens
- ✅ Password hashing with bcrypt (12 rounds)
- ✅ Rate limiting on all endpoints
- ✅ CORS protection
- ✅ Helmet.js security headers
- ✅ File upload validation
- ✅ SQL injection prevention (Prisma)
- ✅ XSS protection

---

## 🚧 Roadmap

### Phase 1 (MVP) ✅
- [x] User authentication
- [x] Resume upload & parsing
- [x] ATS scoring engine
- [x] AI resume analysis
- [x] Mock interview system
- [x] Voice analysis
- [x] Analytics dashboard

### Phase 2 (Q2 2024)
- [ ] Payment integration (Stripe/Chapa)
- [ ] Advanced recruiter personalities
- [ ] Email notifications
- [ ] Resume templates
- [ ] Job board integration

### Phase 3 (Q3 2024)
- [ ] AI avatar interviewers
- [ ] Emotion detection
- [ ] Live coding interviews
- [ ] Team collaboration features
- [ ] Enterprise dashboard

### Phase 4 (Q4 2024)
- [ ] Mobile apps (iOS/Android)
- [ ] Recruiter marketplace
- [ ] API for third-party integrations
- [ ] Advanced analytics & reporting

---

## 🤝 Contributing

Contributions are welcome! Please follow these steps:

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

---

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

---

## 🙏 Acknowledgments

- OpenAI for GPT-4 and Whisper APIs
- Anthropic Claude for development assistance
- The open-source community

---

## 📧 Support

For issues or questions:
- 📫 Email: support@example.com
- 💬 Discord: [Join our community]
- 🐛 Issues: [GitHub Issues](https://github.com/yourusername/ai-resume-trainer/issues)

---

**Built with ❤️ by [Your Name]**
